<?php

require __DIR__ . '/vendor/autoload.php';

use Automattic\WooCommerce\Client;

//$woocommerce = new Client(
//    'http://localhost/',
//    'ck_4d57f6df4cb23579c1dadc969b72956844938200',
//    'cs_dcd65d3ac5962b92770014cd19b193f26458d98a',
//    [
//        'version' => 'wc/v3',
//    ]
//);
//
//$link = mysqli_connect("127.0.0.1", "root", "", "apiwoo_pcservice");


?>